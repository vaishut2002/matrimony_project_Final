import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form6 = () => {
  const [formData, setFormData] = useState({
    Education: '',
    universityName: '',
    Proffession: '',
    companyName: '',
    annualIncome: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
    <div className="container-fluid col-md-12 col-sm-6" >

    <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>
             <div className="row">
           
            <div className="description">
              <h2>Professional Info</h2>
              <p>Please Enter your Basic Details</p>
              <form className="input-form" onSubmit={handleSubmit}>
                  <div className="mb-3 row">
                  <label htmlFor="Education" className="form-label" style={{ fontSize: 'large' }}>Highest Qualification</label>
                  <div className="col-md-10">
                    <select
                      name="Education"
                      id="Education"
                      className="form-control"
                      value={formData.Education}
                      onChange={handleChange}
                    >
                      <option value="">Select Qualification</option>
                      <option value="BSC">B.Sc</option>
                      <option value="MSC">M.Sc</option>
                      <option value="BE">B.E</option>
                      <option value="BTECH">B.Tech</option>
                      <option value="PHD">Ph.D</option>
                      <option value="ME">M.E</option>
                      <option value="MTECH">M.Tech</option>
                      <option value="BCOM">B.Com</option>
                      <option value="MBBS">MBBS</option>
                      <option value="BAMS">BAMS</option>
                      <option value="BHMS">BHMS</option>
                      <option value="MD">M.D</option>
                      <option value="MCOM">M.Com</option>
                      <option value="MBA">MBA</option>
                      <option value="BBA">BBA</option>
                      <option value="DIPLOMA">Diploma</option>
                      <option value="BA">B.A</option>
                      <option value="MA">M.A</option>
                      <option value="TENTH">10th</option>
                      <option value="TWELTH">12th</option>
                      <option value="OTHER">Other</option>
                    </select>
                  </div>
                </div>

              <div className="mb-3 row">
                <label htmlFor="universityName" className=" form-label " style={{ fontSize: 'large' }}>Univesity Or Institution Name</label>
                <div className=" col-md-10">
                  <input
                    type="text"
                    name="universityName"
                    id="universityName"
                    className="form-control"
                    value={formData.universityName}
                    onChange={handleChange}
                    placeholder='Enter the Univesity Or Institution Name'
                  />
                </div>
              </div>
              <div className="mb-10 row">
                <label htmlFor="companyName" className="form-label " style={{ fontSize: 'large' }}>Company Or Buisness name</label>
                <div className="col-md-10 ">
                  <input
                    type="text"
                    name="companyName"
                    id="companyName"
                    className="form-control"
                    value={formData.companyName}
                    onChange={handleChange}
                    placeholder='Enter Company Or Buisness name'
                  />
                </div>
              </div>
              
              <div className="mb-3 row">
                <label htmlFor="annualIncome" className=" form-label" style={{ fontSize: 'large' }}>Annual Income</label>
                <div className=" col-md-10">
                  <input
                    type="number"
                    name="annualIncome"
                    id="annualIncome"
                    className="form-control"
                    value={formData.annualIncome}
                    onChange={handleChange}
                    placeholder='Enter the Annual Income'
                  />
                </div>
              </div>
            
                <button type="submit" className="btn btn-primary " style={{marginBottom:'50px'}}>
                  <span>Save Details</span>
                </button>
                
            </form>
            </div>
          </div>
        </label>        
         </div>
    </>
  )
}
export default Form6;  