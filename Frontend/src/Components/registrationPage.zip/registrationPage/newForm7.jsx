import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form7 = () => {
  const [formData, setFormData] = useState({
    TimeOfBirth: '',
    PlaceOfBirth: '',
    zodiacSign: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
       
    <div className="container-fluid col-md-12 col-sm-6" >

    <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>
                <div className="row">
            <div className="description">
              <h2>Astrological Info</h2>
              <p>Please Enter your Basic Details</p>
              <form className="input-form" onSubmit={handleSubmit}>
              
              <div className="mb-3 row">
                <label htmlFor="height" className=" form-label " style={{ fontSize: 'large' }}>Date And Time Of Birth</label>
                <div className=" col-md-10">
                  <input
                    type="datetime-local"
                    name="TimeOfBirth"
                    id="TimeOfBirth"
                    className="form-control"
                    value={formData.TimeOfBirth}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="mb-3 row">
                <label htmlFor="weight" className="form-label " style={{ fontSize: 'large' }}>Place Of Birth</label>
                <div className="col-md-10 ">
                  <input
                    type="text"
                    name="PlaceOfBirth"
                    id="PlaceOfBirth"
                    className="form-control"
                    value={formData.PlaceOfBirth}
                    onChange={handleChange}
                    placeholder='Enter your Place Of Birth'
                  />
                </div>
              </div>
              
                <button type="submit" className="btn btn-primary animated-button" style={{marginBottom:'50px'}}>
                  <span>Save Details</span>
                </button>
             
            </form>
            </div>
          </div>
              </label>
            </div>
        </>
  )
}  
export default Form7;