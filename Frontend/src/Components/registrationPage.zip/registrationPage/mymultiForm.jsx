import React from "react";

import Form1 from "./newFrom1";
import Form2 from "./newForm2";


const MultiForm =()=> {
  return (
    <>
    <div className="wrapper" style={{ height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
    <div className="container text-center" style={{ height: '800px', display: 'flex', flexWrap: 'nowrap', alignItems: 'center', justifyContent:'flex-start' }}>
     
       <Form1/>
       <Form2/>

        

        <input type="radio" name="slide" id="c4" className="radio" />
        <label htmlFor="c4" className="card">
          <div className="row">
            <div className="icon">4</div>
            <div className="description">
              <h2>Family Info</h2>
              <p>Please Enter your Basic Details</p>
              <form className="input-form">
                <div className="mb-3 row">
                  <label htmlFor="fatherName" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Father's Name</label>
                  <div className="col-sm-10">
                    <input type="text" name="fatherName" id="fatherName" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="motherName" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Mother's Name</label>
                  <div className="col-sm-10">
                    <input type="text" name="motherName" id="motherName" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="siblings" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Siblings</label>
                  <div className="col-sm-10">
                    <input type="text" name="siblings" id="siblings" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="fatherOccupation" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Father's Occupation</label>
                  <div className="col-sm-10">
                    <input type="text" name="fatherOccupation" id="fatherOccupation" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="motherOccupation" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Mother's Occupation</label>
                  <div className="col-sm-10">
                    <input type="text" name="motherOccupation" id="motherOccupation" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="familyIncome" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Family Income</label>
                  <div className="col-sm-10">
                    <input type="text" name="familyIncome" id="familyIncome" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <br /><br /><br /><br />
                <button className="animated-button">
                  <span>Save Details</span>
                  <span></span>
                </button>
              </form>
            </div>
          </div>
        </label>


        <input type="radio" name="slide" id="c6" className="radio" />
        <label htmlFor="c6" className="card">
          <div className="row">
            <div className="icon">6</div>
            <div className="description">
              <h2>Professional Info</h2>
              <p>Please Enter your Basic Details</p>
              <form className="input-form">
                <div className="mb-3 row">
                  <label htmlFor="qualification" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Qualification</label>
                  <div className="col-sm-10">
                    <input type="text" name="qualification" id="qualification" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="institution" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Institution</label>
                  <div className="col-sm-10">
                    <input type="text" name="institution" id="institution" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="workingWith" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Working With</label>
                  <div className="col-sm-10">
                    <input type="text" name="workingWith" id="workingWith" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="workingAs" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Working As</label>
                  <div className="col-sm-10">
                    <input type="text" name="workingAs" id="workingAs" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="annualIncome" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Annual Income</label>
                  <div className="col-sm-10">
                    <input type="text" name="annualIncome" id="annualIncome" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <br /><br /><br /><br />
                <button className="animated-button">
                  <span>Save Details</span>
                  <span></span>
                </button>
              </form>
            </div>
          </div>
        </label>

        <input type="radio" name="slide" id="c7" className="radio" />
        <label htmlFor="c7" className="card">
          <div className="row">
            <div className="icon">7</div>
            <div className="description">
              <h2>Astrological Info</h2>
              <p>Please Enter your Basic Details</p>
              <form className="input-form">
                <div className="mb-3 row">
                  <label htmlFor="birthTime" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Time of Birth</label>
                  <div className="col-sm-10">
                    <input type="text" name="birthTime" id="birthTime" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <div className="mb-3 row">
                  <label htmlFor="birthPlace" className="col-sm-2 col-form-label" style={{ fontSize: 'x-large' }}>Place of Birth</label>
                  <div className="col-sm-10">
                    <input type="text" name="birthPlace" id="birthPlace" className="Name" style={{ width: '300px', height: '30px', boxShadow: 'none' }} />
                  </div>
                </div>
                <br /><br /><br /><br /><br /><br />
                <button className="animated-button">
                  <span>Save Details</span>
                  <span></span>
                </button>
              </form>
            </div>
          </div>
        </label>
      </div>
    </div>
    </> 
  );
}
export default MultiForm;
