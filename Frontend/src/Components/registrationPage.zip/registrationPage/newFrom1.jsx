import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';


const Form1 = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    dob: '',
    gender: '',
    password:'',
    age:'',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
   

           <div className="container col-md-12 col-sm-6">
        <label htmlFor="c2" className="Form" style={{ marginTop: '20px' }}>
          <div className="row">
            <div className="icon"></div>
            <div className="description">
              <h2>Basic Details</h2>
              <p>Please Enter your Basic Details</p>
              <form className="input-form" onSubmit={handleSubmit}>
                <div className="mb-3 row">
                  <label htmlFor="FullName" className="form-label" style={{ fontSize: 'large' }}>Full Name</label>
                  <div className="col-sm-12 col-md-10">
                    <input
                      name="FullName"
                      id="FullName"
                      className="form-control"
                      value={formData.FullName}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                    >
                  
                    </input>
                  </div>
                </div>

                <div className="mb-3 row">
                <label htmlFor="Email" className=" form-label" style={{ fontSize: 'large' }}>Email</label>
                <div className=" col-md-10">
                  <input
                    type="email"
                    name="Email"
                    id="Email"
                    className="form-control"
                    value={formData.Email}
                    onChange={handleChange}
                    placeholder="Abc@mail.com"
                  />
                </div>
              </div>
                

                  <div className="mb-3 row">
                <label htmlFor="dob" className=" form-label" style={{ fontSize: 'large' }}>Date Of Birth</label>
                <div className=" col-md-10">
                  <input
                    type="date"
                    name="Age"
                    id="Age"
                    min={21}
                    className="form-control"
                    value={formData.dob}
                    onChange={handleChange}
                    
                  />
                </div>
              </div>


                <div className="mb-3 row">
                  <label htmlFor="gender" className="form-label" style={{ fontSize: 'large' }}>Gender</label>
                  <div className="col-md-10">
                    <select
                      name="gender"
                      id="gender"
                      className="form-control"
                      value={formData.gender}
                      onChange={handleChange}
                    >
                      <option value="">Select Gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      
                    </select>
                  </div>
                </div>
                <div className="mb-3 row">
                <label htmlFor="password" className=" form-label" style={{ fontSize: 'large' }}>Password</label>
                <div className=" col-md-10">
                  <input
                    type="text"
                    name="password"
                    id="password"
                    className="form-control"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="enter your 6 digit password"
                  />
                </div>
              </div>

              <div className="mb-3 row">
                <label htmlFor="ConfirmPassword" className=" form-label" style={{ fontSize: 'large' }}>Confirm Password</label>
                <div className=" col-md-10">
                  <input
                    type="text"
                    name="ConfirmPassword"
                    id="ConfirmPassword"
                    className="form-control"
                    value={formData.ConfirmPassword}
                    onChange={handleChange}
                    placeholder="Renter your 6 digit password"
                  />
                </div>
              </div>

              <div className="mb-3 row">
                <label htmlFor="age" className=" form-label" style={{ fontSize: 'large' }}>Age</label>
                <div className=" col-md-10">
                  <input
                    type="number"
                    name="age"
                    id="age"
                    min={21}
                    className="form-control"
                    value={formData.age}
                    onChange={handleChange}
                    placeholder="Enter your age"
                  />
                </div>
              </div>

                <button type="submit" className="btn btn-primary" style={{ marginBottom: '50px' }}>
                  <span>Save Details</span>
                </button>
              </form>
            </div>
          </div>
        </label>
      </div>
  
  );
};

export default Form1;

