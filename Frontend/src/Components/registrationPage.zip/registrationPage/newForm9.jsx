import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import PictureContainer from './profilePhoto';


const Form9 = () => {
  const [formData, setFormData] = useState({
    Age: '',
    Email:'',
    Password: '',
    ConfirmPassword : '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
      
    <div className="container col-md-12 col-sm-6" >
        

    <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>

                <div className="row">
                    <div className="icon"></div>
                    <div className="description">
                        <h2>Basic Details </h2>
                        <p>Please Enter your Basic Details</p>

                        <PictureContainer />

                        <form className="input-form" onSubmit={handleSubmit}>
              <div className="mb-3 row">  
              </div>
              
              
              

      
                <button type="submit" className="btn btn-primary " style={{marginBottom:'50px'}}>
                  <span>Save Details</span>
                </button>
             
            </form>
                    </div>
                </div>
            </label>
</div>

    </>
  );
};

export default Form9;

