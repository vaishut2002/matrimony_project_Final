import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { isDisabled } from '@testing-library/user-event/dist/utils';

const Form2 = () => {
  const [formData, setFormData] = useState({
    motherTongue: '',
    height: '',
    weight: '',
    nationality: '',
    isDisabled: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>

    <div className="container-fluid col-md-12 col-sm-6" >

    <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>
       
       
        <div className="row">
        
          <div className="description">
            <h2>Personal Details</h2>
            <p>Please Enter your Basic Details</p>


            <form className="input-form" onSubmit={handleSubmit}>

            <div className="mb-3 row">
              <label htmlFor="motherTongue" className="form-label" style={{ fontSize: 'large' }} >Mother Tongue</label>
              <div className="col-sm-12 col-md-10">
                <select
                  name="motherTongue"
                  id="motherTongue"
                  className="form-control"
                  value={formData.motherTongue}
                  onChange={handleChange}
                >
                  <option value="">Select Mother Tongue</option>
                  <option value="ASSAMESE">Assamese</option>
                  <option value="BENGALI">Bengali</option>
                  <option value="BODO">Bodo</option>
                  <option value="DOGRI">Dogri</option>
                  <option value="ENGLISH">English</option>
                  <option value="GUJARATI">Gujarati</option>
                  <option value="HINDI">Hindi</option>
                  <option value="KANNADA">Kannada</option>
                  <option value="KASHMIRI">Kashmiri</option>
                  <option value="KONKANI">Konkani</option>
                  <option value="MAITHILI">Maithili</option>
                  <option value="MALAYALAM">Malayalam</option>
                  <option value="MANIPURI">Manipuri</option>
                  <option value="MARATHI">Marathi</option>
                  <option value="NEPALI">Nepali</option>
                  <option value="ODIA">Odia</option>
                  <option value="PUNJABI">Punjabi</option>
                  <option value="SANSKRIT">Sanskrit</option>
                  <option value="SANTALI">Santali</option>
                  <option value="SINDHI">Sindhi</option>
                  <option value="TAMIL">Tamil</option>
                  <option value="TELUGU">Telugu</option>
                  <option value="URDU">Urdu</option>
                </select>
              </div>
            </div>
            <div className="mb-3 row">
                    <label htmlFor="height" className="form-label" style={{ fontSize: 'large' }}>Height (in cm)</label>
                    <div className="col-md-10">
                      <input
                        type="number"
                        name="height"
                        id="height"
                        className="form-control"
                        value={formData.height}
                        onChange={handleChange}
                        min="0"  // Minimum value (0 cm or more)
                        step="1"  // Increment step (1 cm increments)
                        placeholder="Enter height in cm"
                      /> 
                    </div>
                  </div>

                  <div className="mb-3 row">
                    <label htmlFor="weight" className="form-label" style={{ fontSize: 'large' }}>Weight (in kg)</label>
                    <div className="col-md-10">
                      <input
                        type="number"
                        name="weight"
                        id="weight"
                        className="form-control"
                        value={formData.weight}
                        onChange={handleChange}
                        min="0"  // Minimum value (0 kg or more)
                        step="1"  // Increment step (1 kg increments)
                        placeholder="Enter weight in kg"
                      /> 
                    </div>
                  </div>

             
                  <div className="mb-3 row">
                    <label htmlFor="nationality" className="form-label" style={{ fontSize: 'large' }}>Nationality</label>
                    <div className='col-md-10'>
                      <select
                        name="nationality"
                        id="nationality"
                        className="form-control"
                        value={formData.Nationality}
                        onChange={handleChange}
                      >
                        <option value="">Select Nationality</option>
                        <option value="American">American</option>
                        <option value="Canadian">Canadian</option>
                        <option value="Indian">Indian</option>
                        <option value="British">British</option>
                        <option value="Australian">Australian</option>
                        <option value="Chinese">Chinese</option>
                        <option value="Japanese">Japanese</option>
                        <option value="German">German</option>
                        <option value="French">French</option>
                        <option value="Spanish">Spanish</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
                  <div className="mb-3 row">
                 <label htmlFor="speciallyAbled" className="form-label" style={{ fontSize: 'large' }}>Specially Abled</label>
                   <div className="col-md-10">
                       <div className="form-check">
                        <input
                                type="radio"
                                name="speciallyAbled"
                                id="speciallyAbledYes"
                                className="form-check-input"
                                value="Yes"
                                checked={formData.speciallyAbled === "Yes"}
                                onChange={handleChange}
                         />
                   <label htmlFor="speciallyAbledYes" className="form-check-label">Yes</label>
                    </div>
                        <div className="form-check">
                        <input
                          type="radio"
                          name="isDisabled"
                          id="isDisabled"
                          className="form-check-input"
                          value="No"
                          checked={formData.speciallyAbled === "No"}
                          onChange={handleChange}
                        />
                        <label htmlFor="" className="form-check-label" value>No</label>
                      </div>
                    </div>
                  </div>
    
                  
                  <div className="mb-3 row">
                    <label htmlFor="maritalStatus" className="form-label" style={{ fontSize: 'large' }}>Marital Status</label>
                    <div className='col-md-10'>
                      <select
                        name="maritalStatus"
                        id="maritalStatus"
                        className="form-control"
                        value={formData.MaritalStatus}
                        onChange={handleChange}
                      > <option value="">Select Marital Status </option>
                        <option value="Awaiting Divorce">Awaiting Divorce</option>
                        <option value="Unmarried">Unmarried</option>
                        <option value="Divorced">Divorced</option>
                        <option value="Widowed">Widowed</option>
                      </select>
                    </div>
                  </div>

              
                <button type="submit" className="btn btn-primary animated-button" style={{marginBottom:'50px'}}>
                  <span>Save Details</span>
                </button>
             
            </form>
          </div>
        </div>
      </label>
    </div>  
    </>
  );
};

export default Form2;
