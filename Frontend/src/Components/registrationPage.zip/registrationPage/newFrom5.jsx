import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form5 = () => {
  const [formData, setFormData] = useState({
    country: '',
    State: '',
    City: '',
    pinCode: '',
    Landmark: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>

    <div className="container col-md-12 col-sm-6" >

    <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>

    <div className="row">
          
            <div className="description">
              <h2>Residential Info</h2>
              <p>Please Enter your Basic Residential Info</p>
                <form className="input-form" onSubmit={handleSubmit}>
              
               
                <div className="mb-3 row">
  <label htmlFor="City" className="form-label" style={{ fontSize: 'large' }}>City</label>
  <div className="col-md-10">
    <select
      name="City"
      id="City"
      className="form-control"
      value={formData.City}
      onChange={handleChange}
    >
      <option value="">Select City</option>
      <option value="Abbigiri">Abbigiri</option>
      <option value="Adakimaranhalli">Adakimaranhalli</option>
      <option value="Ahmedabad">Ahmedabad</option>
      <option value="Aligarh">Aligarh</option>
      <option value="Aliya Kotla">Aliya Kotla</option>
      <option value="Ambapuram">Ambapuram</option>
      <option value="Ambattur">Ambattur</option>
      <option value="Andheri">Andheri</option>
      <option value="Aurangabad">Aurangabad</option>
      <option value="Babura">Babura</option>
      <option value="Balasore">Balasore</option>
      <option value="Bansbaria">Bansbaria</option>
      <option value="Barakpur">Barakpur</option>
      <option value="Bauria">Bauria</option>
      <option value="Bendravadi">Bendravadi</option>
      <option value="Bilaspur">Bilaspur</option>
      <option value="Bhopal">Bhopal</option>
      <option value="Bhatpara">Bhatpara</option>
      <option value="Bhalswa Jahangirpur">Bhalswa Jahangirpur</option>
      <option value="Bhayandar">Bhayandar</option>
      <option value="Chakapara">Chakapara</option>
      <option value="Chandannagar">Chandannagar</option>
      <option value="Chandigarh">Chandigarh</option>
      <option value="Chennai">Chennai</option>
      <option value="Chik Banavar">Chik Banavar</option>
      <option value="Cachohalli">Cachohalli</option>
      <option value="Dam Dam">Dam Dam</option>
      <option value="Dhanbad">Dhanbad</option>
      <option value="Dasarahalli">Dasarahalli</option>
      <option value="Devanandapur">Devanandapur</option>
      <option value="Faridabad">Faridabad</option>
      <option value="Guwahati">Guwahati</option>
      <option value="Gyan Chak">Gyan Chak</option>
      <option value="Haldwani">Haldwani</option>
      <option value="Hariladih">Hariladih</option>
      <option value="Harchandi">Harchandi</option>
      <option value="Herohalli">Herohalli</option>
      <option value="Hesarghetta">Hesarghetta</option>
      <option value="Howrah">Howrah</option>
      <option value="Hunasamaranhalli">Hunasamaranhalli</option>
      <option value="Indore">Indore</option>
      <option value="Jabalpur">Jabalpur</option>
      <option value="Jamshedpur">Jamshedpur</option>
      <option value="Jethuli">Jethuli</option>
      <option value="Jodhpur">Jodhpur</option>
      <option value="Kadikanahalli">Kadiganahalli</option>
      <option value="Kalyan">Kalyan</option>
      <option value="Kankuria">Kankuria</option>
      <option value="Kedihati">Kedihati</option>
      <option value="Kochi">Kochi</option>
      <option value="Kolkata">Kolkata</option>
      <option value="Kukatpalli">Kukatpalli</option>
      <option value="Loni">Loni</option>
      <option value="Lucknow">Lucknow</option>
      <option value="Ludhiana">Ludhiana</option>
      <option value="Madurai">Madurai</option>
      <option value="Madipakkam">Madipakkam</option>
      <option value="Madhavaram">Madhavaram</option>
      <option value="Mahuli">Mahuli</option>
      <option value="Mailanhalli">Mailanhalli</option>
      <option value="Manali">Manali</option>
      <option value="Madavar">Madavar</option>
      <option value="Muzaffarpur">Muzaffarpur</option>
      <option value="Murtazabad">Murtazabad</option>
      <option value="Mumbai">Mumbai</option>
      <option value="Mirzapur">Mirzapur</option>
      <option value="Nagm">Nagpur</option>
      <option value="Nerkunram">Nerkunram</option>
      <option value="Nasik">Nasik</option>
      <option value="Nathupur">Nathupur</option>
      <option value="Najafgarh">Najafgarh</option>
      <option value="Nanmangalam">Nanmangalam</option>
      <option value="New Delhi">New Delhi</option>
      <option value="Oulgaret">Oulgaret</option>
      <option value="Pakri">Pakri</option>
      <option value="Patna">Patna</option>
      <option value="Pallavaram">Pallavaram</option>
      <option value="Puducherry">Puducherry</option>
      <option value="Pune">Pune</option>
      <option value="Prayagraj">Prayagraj</option>
      <option value="Raipur">Raipur</option>
      <option value="Ranchi">Ranchi</option>
      <option value="Rajkot">Rajkot</option>
      <option value="Salua">Salua</option>
      <option value="Sabalpur">Sabalpur</option>
      <option value="Sijua">Sijua</option>
      <option value="Secunderabad">Secunderabad</option>
      <option value="Shimla">Shimla</option>
      <option value="Sonawan">Sonawan</option>
      <option value="Sultanpur">Sultanpur</option>
      <option value="Sultanpur Mazra">Sultanpur Mazra</option>
      <option value="Supaul">Supaul</option>
      <option value="Srinagar">Srinagar</option>
      <option value="Shekhpura">Shekhpura</option>
      <option value="Sonudih">Sonudih</option>
      <option value="Tarchha">Tarchha</option>
      <option value="Titagarh">Titagarh</option>
      <option value="Tribeni">Tribeni</option>
      <option value="Vadodara">Vadodara</option>
      <option value="Vajrahalli">Vajrahalli</option>
      <option value="Vijayawada">Vijayawada</option>
      <option value="Varanasi">Varanasi</option>
      <option value="Vishakhapatnam">Vishakhapatnam</option>
      <option value="Yelahanka">Yelahanka</option>
      <option value="Zeyadah Kot">Zeyadah Kot</option>
    </select>
  </div>
</div>



              <div className="mb-3 row">
                <label htmlFor="speciallyAbled" className=" form-label" style={{ fontSize: 'large' }}>Pin Code</label>
                <div className=" col-md-10">
                  <input
                    type="number"
                    name="speciallyAbled"
                    id="Pin Code"
                    className="form-control"
                    value={formData.PinCode}
                    onChange={handleChange}
                    placeholder='202001'
                  />
                </div>
              </div>
              
                <button type="submit" className="btn btn-primary animated-button" style={{marginBottom:'50px'}}>
                  <span>Save Details</span>
                </button>
             
            </form>
            </div>
          </div>
        </label>


    </div>
    </>
  )
}
export default Form5;