import React, { Component } from "react";

import Form2 from "./newForm2";
import Form1 from "./newFrom1"
import CheckoutStepper from "./myProgressBar";
import Form3 from "./newForm3";
import Form4 from "./newForm4";
import Form5 from "./newFrom5";
import Form6 from "./newForm6";
import Form7 from "./newForm7";
import Form8 from "./newForm8";
import Form9 from "./newForm9";
import Form10 from "./newForm10";

const CHECKOUT_STEPS = [
    {
      name: "Basic Details",
      Component: () => <div><Form1></Form1></div>,
    },
    {
      name: "Personal Details",
      Component: () => <div><Form2></Form2></div>,
    },
    {
      name: "LifeStyle Details" ,
      Component: () =><div>
        <Form10/>
      </div>
    },

    {
      name: "Religion Info",
      Component: () => <div><Form3/></div>,
    },
    {
      name: "Family Info",
      Component: () => <div><Form4/></div>,
    },
    {
        name: "Residential Info",
       Component: () =><div>
            <Form5></Form5>
       </div>
    },
    {
        name: "Professional Info",
       Component: () =><div>
        <Form6></Form6>
       </div>
    },
    {
        name: "Astrological Info",
       Component: () =><div>
        <Form7></Form7>
       </div>
    },
    {
      name:"Partner Prefrence",
      Component: ()=><div>
        <Form8></Form8>
      </div>
    },
    {
      name:"Last Details",
      Component:()=><div>
        <Form9/>
      </div>
    }
  ];


const MyForms =()=> {
  return (
    <>
     <div>
      <h2>Registration Form</h2>
      <CheckoutStepper stepsConfig={CHECKOUT_STEPS} />
    </div>
    </>
  )
}
export default MyForms;