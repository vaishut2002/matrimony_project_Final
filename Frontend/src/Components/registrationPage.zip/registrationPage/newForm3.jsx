import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form3 = () => {
  const [formData, setFormData] = useState({
    Religion: '',
    CasteSect: '',
    Gotra: '',
    motherTongue: '',
    ZodiacSign: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
      
        <div className="container col-md-12 col-sm-6">
          <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>
            <div className="row">
              <div className="icon"></div>
              <div className="description">
                <h2>Religion Info</h2>
                <p>Please Enter your Basic Details</p>
                <form className="input-form" onSubmit={handleSubmit}>
                
                  <div className="mb-3 row">
                    <label htmlFor="religion" className="form-label">Religion</label><br />
                    <div className=" col-md-10">
                      <select
                        name="religion"
                        id="religion"
                        className="form-control"
                        value={formData.religion}
                        onChange={handleChange}
                      >
                        <option value="">Select Religion</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Muslim">Muslim</option>
                        <option value="Christian">Christian</option>
                        <option value="Sikh">Sikh</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>
  
                  <div className="mb-3 row">
                      <label htmlFor="caste" className="form-label" style={{ fontSize: 'large' }}>Caste / Sect</label>
                      <div className="col-md-10">
                        <select
                          name="caste"
                          id="caste"
                          className="form-control"
                          value={formData.caste}
                          onChange={handleChange}
                        >
                          <option value="">Select Caste / Sect</option>
                          <option value="Brahmin">Brahmin</option>
                          <option value="Kshatriya">Kshatriya</option>
                          <option value="Yadav">Yadav</option>
                          <option value="Bhumihar">Bhumihar</option>
                          <option value="Gujjar">Gujjar</option>
                          <option value="Maratha">Maratha</option>
                          <option value="Kumbhar">Kumbhar</option>
                          <option value="Chambhar">Chambhar</option>
                          <option value="Jat">Jat</option>
                          <option value="Lohar">Lohar</option>
                          <option value="Kurmi">Kurmi</option>
                          <option value="Teli">Teli</option>
                          <option value="Qureshi">Qureshi</option>
                          <option value="Khan">Khan</option>
                          <option value="Pathan">Pathan</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>
                    </div>
                    <div className="mb-3 row">
                    <label htmlFor="zodiacSign" className="form-label" style={{ fontSize: 'large' }}>Zodiac Sign</label>
                    <div className="col-md-10">
                      <select
                        name="zodiacSign"
                        id="zodiacSign"
                        className="form-control"
                        value={formData.zodiacSign}
                        onChange={handleChange}
                      >
                        <option value="">Select Zodiac Sign</option>
                        <option value="Aries">Aries</option>
                        <option value="Taurus">Taurus</option>
                        <option value="Gemini">Gemini</option>
                        <option value="Cancer">Cancer</option>
                        <option value="Leo">Leo</option>
                        <option value="Virgo">Virgo</option>
                        <option value="Libra">Libra</option>
                        <option value="Scorpio">Scorpio</option>
                        <option value="Sagittarius">Sagittarius</option>
                        <option value="Capricorn">Capricorn</option>
                        <option value="Aquarius">Aquarius</option>
                        <option value="Pisces">Pisces</option>
                      </select>
                    </div>
                  </div>
  
                  
                  
                  <button type="submit" className="btn btn-primary animated-button" style={{marginBottom:'50px'}}>
                    <span>Save Details</span>
                  </button>
                
                </form>
              </div>
            </div>
          </label>
        </div>
    </>
  );
}
export default Form3;