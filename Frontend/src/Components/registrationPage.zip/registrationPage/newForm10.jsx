import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form10 = () => {
  const [formData, setFormData] = useState({
    Alcohol: '',
    NonAlcohol: '',
    Smoker: '',
    NonSmoker: '',
   
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
       
            <div className="container col-md-12 col-sm-6" >
                <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>

                    <div className="row">
                        <h2>Life Style Information</h2>
                        <p>Lets See whats your LifeStyle Choices are </p>
                        <form className="input-form" onSubmit={handleSubmit}>

                        
                            <div className="mb-3 row">
                                <div className="form-check">
                                <label htmlFor="Dietryhabbits" className="form-label" style={{ fontSize: 'large' }}>Dietary Habits</label>
                                <div className='col'>
                                    <input className="form-check-input" type="radio" name="Dietryhabbits" id="Vegetarian" value="Vegetarian" onChange={handleChange} />
                                    <label className="form-check-label" htmlFor="Vegetarian">Vegetarian</label>
                                </div>
                                <div className='col'>
                                    <input className="form-check-input" type="radio" name="Dietryhabbits" id="NonVegetarian" value="NonVegetarian" onChange={handleChange} />
                                    <label className="form-check-label" htmlFor="NonVegetarian">Non-Vegetarian</label>
                                </div>
                                </div>
                            </div>
                             
                                <div className="mb-3 row">
                                    <div className="form-check">
                                    <label htmlFor="Lifestyle" className="form-label" style={{ fontSize: 'large' }}>Lifestyle</label>
                                    <div className='col'>
                                        <input
                                        className="form-check-input"
                                        type="checkbox"
                                        name="Lifestyle"
                                        id="Smoker"
                                        value="Smoker"
                                        
                                        onChange={handleChange}
                                        />
                                        <label className="form-check-label" htmlFor="Smoker">Smoker</label>
                                    </div>
                                    <div className='col'>
                                        <input
                                        className="form-check-input"
                                        type="checkbox"
                                        name="Lifestyle"
                                        id="Drinker"
                                        value="Drinker"
                                        
                                        onChange={handleChange}
                                        />
                                        <label className="form-check-label" htmlFor="Drinker">Drinker</label>
                                    </div>
                                    </div>
                                </div>
                           
                            <button type="submit" className="btn btn-primary animated-button" style={{marginBottom:'50px'}}>
                                <span>Save Details</span>
                            </button>
                        </form>
                    </div>
                </label>
            </div>
    </>
);

}
export default Form10;