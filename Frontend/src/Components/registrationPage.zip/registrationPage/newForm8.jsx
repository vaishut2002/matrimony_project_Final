import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form8 = () => {
  const [formData, setFormData] = useState({
    MaritalStatus: '',
    Religion: '',
    Education: '',
    PreferedCountry: '',
    PreferedCity: '',
    PreferedState: '',
    PreferedAgeMin: '',
    PreferedAgeMax: '',
    ExtraHabbits: '',
    Dietryhabbits: '',
    Lifestyle: [], // for checkbox values
    annualIncome: '',
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === 'checkbox') {
      setFormData((prevData) => {
        const newLifestyle = checked
          ? [...prevData.Lifestyle, value]
          : prevData.Lifestyle.filter((item) => item !== value);
        return { ...prevData, Lifestyle: newLifestyle };
      });
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
      <div className="container col-md-12 col-sm-6">
        <div className="row">
          <div className="icon"></div>
          <div className="description">
            <h2>Partner Preference</h2>
            <p>Let's go through what is your preferred partner</p>
            <form className="input-form" onSubmit={handleSubmit}>
              {/* Marital Status */}
              <div className="mb-3 row">
                <label htmlFor="MaritalStatus" className="form-label" style={{ fontSize: 'large' }}>
                  Marital Status
                </label>
                <div className="col-mb-5">
                  <select
                    name="MaritalStatus"
                    id="MaritalStatus"
                    className="form-control"
                    value={formData.MaritalStatus}
                    onChange={handleChange}
                  >
                    <option value="">Select Marital Status</option>
                    <option value="Awaiting Divorce">Awaiting Divorce</option>
                    <option value="Unmarried">Unmarried</option>
                    <option value="Divorced">Divorced</option>
                    <option value="Widowed">Widowed</option>
                  </select>
                </div>
              </div>

              {/* Dietary Habits */}
              <div className="mb-3 row">
                <label htmlFor="Dietryhabbits" className="form-label" style={{ fontSize: 'large' }}>
                  Dietary Habits
                </label>
                <div className="col">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="Dietryhabbits"
                    id="Vegetarian"
                    value="Vegetarian"
                    checked={formData.Dietryhabbits === ' Vegetarian'}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor=" Vegetarian ">
                      Vegetarian
                  </label>
                </div>
                <div className="col">
                  <input
                    className="form-check-input"
                    type="radio"
                    name="Dietryhabbits"
                    id="NonVegetarian"
                    value="NonVegetarian"
                    checked={formData.Dietryhabbits === ' NonVegetarian'}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor=" NonVegetarian ">
                      Non-Vegetarian
                  </label>
                </div>
              </div>

              {/* Lifestyle */}
              <div className="mb-3 row">
                <label htmlFor="Lifestyle" className="form-label" style={{ fontSize: 'large' }}>
                  Lifestyle
                </label>
                <div className="col">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    name="Lifestyle"
                    id="Smoker"
                    value="Smoker"
                    checked={formData.Lifestyle.includes(' Smoker')}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor=" Smoker ">
                     Smoker
                  </label>
                </div>
                <div className="col">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    name="Lifestyle"
                    id="Drinker"
                    value="Drinker"
                    checked={formData.Lifestyle.includes(' Drinker')}
                    onChange={handleChange}
                  />
                  <label className="form-check-label" htmlFor=" Drinker ">
                    Drinker
                  </label>
                </div>
              </div>

              {/* Age Range */}
              <div className="mb-3 row">
                <label htmlFor="PreferedAgeMin" className="form-label" style={{ fontSize: 'large' }}>
                  Age Range
                </label>
                <div className="col-md-5">
                  <input
                    type="number"
                    name="PreferedAgeMin"
                    id="PreferedAgeMin"
                    className="form-control"
                    min={21}
                    max={100}
                    placeholder="Min Age"
                    value={formData.PreferedAgeMin}
                    onChange={handleChange}
                  />
                </div>
                <div className="col-md-5">
                  <input
                    type="number"
                    name="PreferedAgeMax"
                    id="PreferedAgeMax"
                    className="form-control"
                    min={21}
                    max={100}
                    placeholder="Max Age"
                    value={formData.PreferedAgeMax}
                    onChange={handleChange}
                  />
                </div>
              </div>

              {/* Highest Qualification */}
              <div className="mb-3 row">
                <label htmlFor="Education" className="form-label" style={{ fontSize: 'large' }}>
                  Highest Qualification
                </label>
                <div className="col-md-10">
                  <select
                    name="Education"
                    id="Education"
                    className="form-control"
                    value={formData.Education}
                    onChange={handleChange}
                  >
                    <option value="">Select Qualification</option>
                    <option value="BSC">B.Sc</option>
                    <option value="MSC">M.Sc</option>
                    <option value="BE">B.E</option>
                    <option value="BTECH">B.Tech</option>
                    <option value="PHD">Ph.D</option>
                    <option value="ME">M.E</option>
                    <option value="MTECH">M.Tech</option>
                    <option value="BCOM">B.Com</option>
                    <option value="MBBS">MBBS</option>
                    <option value="BAMS">BAMS</option>
                    <option value="BHMS">BHMS</option>
                    <option value="MD">M.D</option>
                    <option value="MCOM">M.Com</option>
                    <option value="MBA">MBA</option>
                    <option value="BBA">BBA</option>
                    <option value="DIPLOMA">Diploma</option>
                    <option value="BA">B.A</option>
                    <option value="MA">M.A</option>
                    <option value="TENTH">10th</option>
                    <option value="TWELTH">12th</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>
              </div>

              <div className="mb-3 row">
                <label htmlFor="City" className="form-label" style={{ fontSize: 'large' }}>
                  City
                </label>
                <div className="col-md-10">
                  <select
                    name="City"
                    id="City"
                    className="form-control"
                    value={formData.Education}
                    onChange={handleChange}
                  >
                   <option value="">Select City</option>
      <option value="Abbigiri">Abbigiri</option>
      <option value="Adakimaranhalli">Adakimaranhalli</option>
      <option value="Ahmedabad">Ahmedabad</option>
      <option value="Aligarh">Aligarh</option>
      <option value="Aliya Kotla">Aliya Kotla</option>
      <option value="Ambapuram">Ambapuram</option>
      <option value="Ambattur">Ambattur</option>
      <option value="Andheri">Andheri</option>
      <option value="Aurangabad">Aurangabad</option>
      <option value="Babura">Babura</option>
      <option value="Balasore">Balasore</option>
      <option value="Bansbaria">Bansbaria</option>
      <option value="Barakpur">Barakpur</option>
      <option value="Bauria">Bauria</option>
      <option value="Bendravadi">Bendravadi</option>
      <option value="Bilaspur">Bilaspur</option>
      <option value="Bhopal">Bhopal</option>
      <option value="Bhatpara">Bhatpara</option>
      <option value="Bhalswa Jahangirpur">Bhalswa Jahangirpur</option>
      <option value="Bhayandar">Bhayandar</option>
      <option value="Chakapara">Chakapara</option>
      <option value="Chandannagar">Chandannagar</option>
      <option value="Chandigarh">Chandigarh</option>
      <option value="Chennai">Chennai</option>
      <option value="Chik Banavar">Chik Banavar</option>
      <option value="Cachohalli">Cachohalli</option>
      <option value="Dam Dam">Dam Dam</option>
      <option value="Dhanbad">Dhanbad</option>
      <option value="Dasarahalli">Dasarahalli</option>
      <option value="Devanandapur">Devanandapur</option>
      <option value="Faridabad">Faridabad</option>
      <option value="Guwahati">Guwahati</option>
      <option value="Gyan Chak">Gyan Chak</option>
      <option value="Haldwani">Haldwani</option>
      <option value="Hariladih">Hariladih</option>
      <option value="Harchandi">Harchandi</option>
      <option value="Herohalli">Herohalli</option>
      <option value="Hesarghetta">Hesarghetta</option>
      <option value="Howrah">Howrah</option>
      <option value="Hunasamaranhalli">Hunasamaranhalli</option>
      <option value="Indore">Indore</option>
      <option value="Jabalpur">Jabalpur</option>
      <option value="Jamshedpur">Jamshedpur</option>
      <option value="Jethuli">Jethuli</option>
      <option value="Jodhpur">Jodhpur</option>
      <option value="Kadikanahalli">Kadiganahalli</option>
      <option value="Kalyan">Kalyan</option>
      <option value="Kankuria">Kankuria</option>
      <option value="Kedihati">Kedihati</option>
      <option value="Kochi">Kochi</option>
      <option value="Kolkata">Kolkata</option>
      <option value="Kukatpalli">Kukatpalli</option>
      <option value="Loni">Loni</option>
      <option value="Lucknow">Lucknow</option>
      <option value="Ludhiana">Ludhiana</option>
      <option value="Madurai">Madurai</option>
      <option value="Madipakkam">Madipakkam</option>
      <option value="Madhavaram">Madhavaram</option>
      <option value="Mahuli">Mahuli</option>
      <option value="Mailanhalli">Mailanhalli</option>
      <option value="Manali">Manali</option>
      <option value="Madavar">Madavar</option>
      <option value="Muzaffarpur">Muzaffarpur</option>
      <option value="Murtazabad">Murtazabad</option>
      <option value="Mumbai">Mumbai</option>
      <option value="Mirzapur">Mirzapur</option>
      <option value="Nagm">Nagpur</option>
      <option value="Nerkunram">Nerkunram</option>
      <option value="Nasik">Nasik</option>
      <option value="Nathupur">Nathupur</option>
      <option value="Najafgarh">Najafgarh</option>
      <option value="Nanmangalam">Nanmangalam</option>
      <option value="New Delhi">New Delhi</option>
      <option value="Oulgaret">Oulgaret</option>
      <option value="Pakri">Pakri</option>
      <option value="Patna">Patna</option>
      <option value="Pallavaram">Pallavaram</option>
      <option value="Puducherry">Puducherry</option>
      <option value="Pune">Pune</option>
      <option value="Prayagraj">Prayagraj</option>
      <option value="Raipur">Raipur</option>
      <option value="Ranchi">Ranchi</option>
      <option value="Rajkot">Rajkot</option>
      <option value="Salua">Salua</option>
      <option value="Sabalpur">Sabalpur</option>
      <option value="Sijua">Sijua</option>
      <option value="Secunderabad">Secunderabad</option>
      <option value="Shimla">Shimla</option>
      <option value="Sonawan">Sonawan</option>
      <option value="Sultanpur">Sultanpur</option>
      <option value="Sultanpur Mazra">Sultanpur Mazra</option>
      <option value="Supaul">Supaul</option>
      <option value="Srinagar">Srinagar</option>
      <option value="Shekhpura">Shekhpura</option>
      <option value="Sonudih">Sonudih</option>
      <option value="Tarchha">Tarchha</option>
      <option value="Titagarh">Titagarh</option>
      <option value="Tribeni">Tribeni</option>
      <option value="Vadodara">Vadodara</option>
      <option value="Vajrahalli">Vajrahalli</option>
      <option value="Vijayawada">Vijayawada</option>
      <option value="Varanasi">Varanasi</option>
      <option value="Vishakhapatnam">Vishakhapatnam</option>
      <option value="Yelahanka">Yelahanka</option>
      <option value="Zeyadah Kot">Zeyadah Kot</option>
    </select>
  </div>
</div>

              {/* Religion */}
              <div className="mb-3 row">
                <label htmlFor="Religion" className="form-label" style={{ fontSize: 'large' }}>
                  Religion
                </label>
                <div className="col-md-10">
                  <select
                    name="Religion"
                    id="Religion"
                    className="form-control"
                    value={formData.Religion}
                    onChange={handleChange}
                  >
                    <option value="">Select Religion</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Muslim">Muslim</option>
                    <option value="Christian">Christian</option>
                    <option value="Sikh">Sikh</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Annual Income */}
              <div className="mb-3 row">
                <label htmlFor="annualIncome" className="form-label" style={{ fontSize: 'large' }}>
                  Annual Income
                </label>
                <div className="col-md-10">
                  <input
                    type="number"
                    name="annualIncome"
                    id="annualIncome"
                    className="form-control"
                    value={formData.annualIncome}
                    onChange={handleChange}
                    placeholder="Enter the Annual Income"
                  />
                </div>
              </div>

              <button type="submit" className="btn btn-primary" style={{ marginBottom: '50px' }}>
                Save Details
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Form8;
