import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './myProgressBar.css';
import axios from 'axios';

import { useEffect, useRef, useState } from 'react';

const CheckoutStepper = ({ stepsConfig = [] }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isComplete, setIsComplete] = useState(false);
  const [margins, setMargins] = useState({
    marginLeft: 0,
    marginRight: 0,
  });
  const stepRef = useRef([]);

  useEffect(() => {
    setMargins({
      marginLeft: stepRef.current[0]?.offsetWidth / 2 || 0,
      marginRight: stepRef.current[stepsConfig.length - 1]?.offsetWidth / 2 || 0,
    });
  }, [stepsConfig.length]);

  if (!stepsConfig.length) {
    return null;
  }
  const handleNext = () => {
    setCurrentStep((prevStep) => {
      if (prevStep === stepsConfig.length) {
        setIsComplete(true);
  
        // API call using axios
        axios.post('http://localhost:8080/test', {
          data: 'your data' // Add request body if needed
        })
        .then(response => {
          console.log('Success:', response.data);
        })
        .catch(error => {
          console.error('Error:', error);
        });
  
        return prevStep;
      } else {
        return prevStep + 1;
      }
    });
  };

  const handleBack = () => {
    setCurrentStep((prevStep) => {
      if (prevStep > 1) {
        return prevStep - 1;
      } else {
        return prevStep;
      }
    });
  };

  const calculateProgressBarWidth = () => {
    return ((currentStep - 1) / (stepsConfig.length - 1)) * 100;
  };

  const ActiveComponent = stepsConfig[currentStep - 1]?.Component;

  return (
    <>
    <div className='container'>
      <div className="stepper">
        {stepsConfig.map((step, index) => (
          <div
            key={step.name}
            ref={(el) => (stepRef.current[index] = el)}
            className={`step ${currentStep > index + 1 || isComplete ? 'complete' : ''} ${
              currentStep === index + 1 ? 'active' : ''
            }`}
          >
            <div className="step-number">
              {currentStep > index + 1 || isComplete ? <span>&#10003;</span> : index + 1}
            </div>
            <div className="step-name">{step.name}</div>
          </div>
        ))}

        <div className="progress" role="progressbar" aria-label="Progress">
          <div
            className="progress-bar bg-success"
            style={{ width: `calc(100% - ${margins.marginLeft + margins.marginRight}px)` }}
          ></div>
          <div className="progress-bar" style={{ width: `${calculateProgressBarWidth()}%` }}></div>
        </div>
      </div>

      {ActiveComponent && <ActiveComponent />}

      <div className="container col-md-4 col-sm-5" style={{zIndex:2 , position:'absolute',background:'2196F3', marginLeft:'35%', marginTop:'-5.66%'}}>
        <button className="btn btn-secondary" onClick={handleBack} disabled={currentStep === 1} style={{marginRight:'15%'}}>
          Back
        </button>
        {!isComplete && (
          <button className="btn btn-primary" onClick={handleNext} style={{ marginRight:'50%'}}>
            {currentStep === stepsConfig.length ? 'Finish' : 'Next'}
          </button>
        )}
        </div>
      </div>  
    </>
  );
};

export default CheckoutStepper;
