import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const Form4 = () => {
  const [formData, setFormData] = useState({
    FathersName: '',
    MothersName: '',
    NoOfSiblings: '',
    FathersOccupation: '',
    MothersOccupation: '',
    FamilyIncome : '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data:', formData);
  };

  return (
    <>
       
            <div className="container col-md-12 col-sm-6" >
                <label htmlFor="c2" className="Form " style={{ marginTop:'20px', marginLeft:''}}>
                    <div className="row">
                        <h2>Family Info</h2>
                        <p>Please Enter your Basic Details</p>
                        <form className="input-form" onSubmit={handleSubmit}>
                            <div className="mb-3 row">
                                <label htmlFor="fathersName" className="form-label" style={{ fontSize: 'large' }}>Father's Name</label>
                                <div className=" col-md-5">
                                    <input
                                        type="text"
                                        name="fathersName"
                                        id="fathersName"
                                        className="form-control"
                                        value={formData.fathersName}
                                        onChange={handleChange}
                                        placeholder='Enter your fathers name'
                                    />
                                </div>
                            </div>
                            <div className="mb-3 row">
                                <label htmlFor="mothersName" className="form-label" style={{ fontSize: 'large' }}>Mother's Name</label>
                                <div className="col-md-5">
                                    <input
                                        type="text"
                                        name="mothersName"
                                        id="mothersName"
                                        className="form-control"
                                        value={formData.mothersName}
                                        onChange={handleChange}
                                         placeholder='Enter your mothers name'
                                    />
                                </div>
                            </div>
                            <div className="mb-10 row">
                                <label htmlFor="noOfSiblings" className="form-label" style={{ fontSize: 'large' }}>No of Siblings</label>
                                <div className="col-md-5">
                                    <input
                                        type="number"
                                        name="noOfSiblings"
                                        id="noOfSiblings"
                                        className="form-control"
                                        value={formData.noOfSiblings}
                                        onChange={handleChange}
                                        placeholder='No. of siblings'
                                    />
                                </div>
                            </div>
                            <div className="mb-3 row">
                                <label htmlFor="familyIncome" className="form-label" style={{ fontSize: 'large' }}>Family Income</label>
                                <div className="col-md-5">
                                    <input
                                        type="number"
                                        name="familyIncome"
                                        id="familyIncome"
                                        className="form-control"
                                        value={formData.familyIncome}
                                        onChange={handleChange}
                                         placeholder='Family income'
                                    />
                                </div>
                            </div>
                            <button type="submit" className="btn btn-primary animated-button" style={{marginBottom:'50px'}}>
                                <span>Save Details</span>
                            </button>
                        </form>
                    </div>
                </label>
            </div>
    </>
);

}
export default Form4;